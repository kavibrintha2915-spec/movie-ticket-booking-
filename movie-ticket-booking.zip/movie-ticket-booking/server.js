// CineBook - movie ticket booking backend
// Express API + JSON-file database (data/db.json). No external DB needed.

const express = require('express');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_DIR = path.join(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

/* ------------------------------------------------------------------ */
/* Static catalogue (movies, theatres, seat layout, pricing)           */
/* ------------------------------------------------------------------ */
const MOVIES = [
  { id: 1, title: 'Midnight Express Run', language: 'English', genre: 'Action, Thriller', duration: '2h 14m', rating: 8.1, certificate: 'UA', emoji: '🚄', colors: ['#7f1d1d', '#111827'], director: 'Karen Whitfield', cast: 'Daniel Ortiz, Mei Tanaka, Rohan Pillai', description: 'A retired train engineer must stop a runaway night express carrying a secret that powerful people want buried.' },
  { id: 2, title: 'Kaveri Kadhal', language: 'Tamil', genre: 'Romance, Drama', duration: '2h 36m', rating: 8.6, certificate: 'U', emoji: '🌾', colors: ['#065f46', '#1e3a8a'], director: 'Ilango Rajan', cast: 'Arvind Kumar, Meenakshi Sundaram, Sathya Priya', description: 'Two childhood friends from rival farming families find love along the banks of the Kaveri river.' },
  { id: 3, title: 'Last Orbit', language: 'English', genre: 'Sci-Fi, Adventure', duration: '2h 28m', rating: 7.9, certificate: 'UA', emoji: '🚀', colors: ['#312e81', '#0f172a'], director: 'Elena Marsh', cast: 'Priya Nair, Tom Holloway, Yuki Sato', description: 'The crew of a failing space station has 72 hours to decide who goes home and who stays behind.' },
  { id: 4, title: 'Dhoom Dhadaka', language: 'Hindi', genre: 'Comedy, Family', duration: '2h 05m', rating: 7.4, certificate: 'U', emoji: '🎉', colors: ['#b45309', '#9d174d'], director: 'Anil Deshmukh', cast: 'Rahul Mehra, Sneha Kapoor, Vikram Sethi', description: 'A chaotic wedding week turns hilarious when the groom and the caterer swap places by mistake.' },
  { id: 5, title: 'Veera Thandavam', language: 'Telugu', genre: 'Action, Drama', duration: '2h 45m', rating: 8.3, certificate: 'UA', emoji: '⚔️', colors: ['#78350f', '#1f2937'], director: 'Srinivas Varma', cast: 'Karthik Reddy, Anjali Devi, Naveen Babu', description: 'A village guard rises against a corrupt landlord in an epic tale of courage and sacrifice.' },
  { id: 6, title: 'The Quiet House', language: 'English', genre: 'Horror, Mystery', duration: '1h 52m', rating: 7.2, certificate: 'A', emoji: '🏚️', colors: ['#1f2937', '#000000'], director: 'Marcus Bell', cast: 'Olivia Grant, Ethan Cole, Ruth Adeyemi', description: 'A family moves into a perfectly silent house and slowly discovers why nobody ever stayed.' },
  { id: 7, title: 'Chennai Express Diaries', language: 'Tamil', genre: 'Comedy, Drama', duration: '2h 10m', rating: 7.8, certificate: 'U', emoji: '🚉', colors: ['#0e7490', '#4c1d95'], director: 'Prakash Subbu', cast: 'Dinesh Raj, Lakshmi Narayan, Bala Murugan', description: 'Five strangers on an overnight train journey end up changing each other\'s lives forever.' },
  { id: 8, title: 'Paper Planes', language: 'Hindi', genre: 'Drama, Family', duration: '2h 02m', rating: 8.4, certificate: 'U', emoji: '✈️', colors: ['#1d4ed8', '#0f766e'], director: 'Meera Joshi', cast: 'Aarav Sharma, Ishita Rao, Kabir Malhotra', description: 'A ten-year-old boy builds paper planes to send messages to his father working abroad.' }
];

const THEATRES = [
  { id: 't1', name: 'Galaxy Cinemas', area: 'City Centre' },
  { id: 't2', name: 'Starline Multiplex', area: 'Mall Road' },
  { id: 't3', name: 'Royal Screens', area: 'Old Town' }
];

const TIMES = ['10:00 AM', '01:30 PM', '06:15 PM', '09:45 PM'];
const ROWS = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'];
const COLS = 10;
const ROW_PRICE = { A: 150, B: 150, C: 150, D: 200, E: 200, F: 200, G: 300, H: 300 };
const ROW_CLASS = { A: 'Silver', B: 'Silver', C: 'Silver', D: 'Gold', E: 'Gold', F: 'Gold', G: 'Platinum', H: 'Platinum' };
const FEE_PER_TICKET = 30;
const GST_RATE = 0.18; // on convenience fee
const MAX_SEATS = 8;
const PAYMENT_METHODS = ['debit', 'netbanking', 'phonepe', 'gpay', 'paytm'];
const SESSION_DAYS = 7;

/* ------------------------------------------------------------------ */
/* JSON database helpers                                               */
/* ------------------------------------------------------------------ */
function loadDb() {
  if (!fs.existsSync(DB_FILE)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
    fs.writeFileSync(DB_FILE, JSON.stringify({ users: [], sessions: [], bookings: [] }, null, 2));
  }
  return JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
}
function saveDb(db) {
  fs.writeFileSync(DB_FILE + '.tmp', JSON.stringify(db, null, 2));
  fs.renameSync(DB_FILE + '.tmp', DB_FILE);
}

/* ------------------------------------------------------------------ */
/* Utility helpers                                                     */
/* ------------------------------------------------------------------ */
function hashPassword(pw, salt = crypto.randomBytes(16).toString('hex')) {
  return salt + ':' + crypto.scryptSync(pw, salt, 64).toString('hex');
}
function verifyPassword(pw, stored) {
  const [salt, hash] = stored.split(':');
  const test = crypto.scryptSync(pw, salt, 64);
  return crypto.timingSafeEqual(test, Buffer.from(hash, 'hex'));
}
function publicUser(u) {
  return { id: u.id, name: u.name, email: u.email, phone: u.phone };
}
function pad(n) { return String(n).padStart(2, '0'); }
function fmtDate(d) { return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`; }
function nextDates(count = 5) {
  const out = [];
  for (let i = 0; i < count; i++) {
    const d = new Date();
    d.setDate(d.getDate() + i);
    out.push(fmtDate(d));
  }
  return out;
}
function showStart(date, time) {
  const [hm, ap] = time.split(' ');
  let [h, m] = hm.split(':').map(Number);
  if (ap === 'PM' && h !== 12) h += 12;
  if (ap === 'AM' && h === 12) h = 0;
  const [y, mo, d] = date.split('-').map(Number);
  return new Date(y, mo - 1, d, h, m);
}
function bad(res, msg, code = 400) { return res.status(code).json({ error: msg }); }

function validateShow({ movieId, theatreId, date, time }) {
  const movie = MOVIES.find(m => m.id === Number(movieId));
  if (!movie) return { error: 'Movie not found' };
  const theatre = THEATRES.find(t => t.id === theatreId);
  if (!theatre) return { error: 'Theatre not found' };
  if (!TIMES.includes(time)) return { error: 'Invalid show time' };
  if (!nextDates().includes(date)) return { error: 'Invalid show date' };
  if (showStart(date, time) < new Date()) return { error: 'This show has already started' };
  return { movie, theatre };
}
function seatPrice(seat) { return ROW_PRICE[seat[0]]; }
function validateSeats(seats) {
  if (!Array.isArray(seats) || seats.length < 1) return 'Select at least one seat';
  if (seats.length > MAX_SEATS) return `You can book at most ${MAX_SEATS} seats`;
  if (new Set(seats).size !== seats.length) return 'Duplicate seats selected';
  for (const s of seats) {
    if (typeof s !== 'string' || !/^[A-H](10|[1-9])$/.test(s)) return 'Invalid seat: ' + s;
  }
  return null;
}
function quote(seats) {
  const items = seats.map(s => ({ seat: s, class: ROW_CLASS[s[0]], price: seatPrice(s) }));
  const subtotal = items.reduce((a, i) => a + i.price, 0);
  const fee = FEE_PER_TICKET * seats.length;
  const gst = Math.round(fee * GST_RATE);
  return { items, subtotal, fee, gst, total: subtotal + fee + gst };
}
function bookedSeats(db, movieId, theatreId, date, time) {
  return db.bookings
    .filter(b => b.status === 'confirmed' && b.movieId === Number(movieId) && b.theatreId === theatreId && b.date === date && b.time === time)
    .flatMap(b => b.seats);
}

/* ------------------------------------------------------------------ */
/* Auth middleware                                                     */
/* ------------------------------------------------------------------ */
function auth(req, res, next) {
  const h = req.headers.authorization || '';
  const token = h.startsWith('Bearer ') ? h.slice(7) : null;
  const db = loadDb();
  const session = db.sessions.find(s => s.token === token);
  if (!session || new Date(session.expires) < new Date()) return bad(res, 'Please log in to continue', 401);
  const user = db.users.find(u => u.id === session.userId);
  if (!user) return bad(res, 'Please log in to continue', 401);
  req.db = db; req.user = user; req.token = token;
  next();
}
function createSession(db, userId) {
  const token = crypto.randomBytes(32).toString('hex');
  const expires = new Date(Date.now() + SESSION_DAYS * 86400000).toISOString();
  db.sessions = db.sessions.filter(s => new Date(s.expires) > new Date());
  db.sessions.push({ token, userId, expires });
  return token;
}

/* ------------------------------------------------------------------ */
/* Auth routes                                                         */
/* ------------------------------------------------------------------ */
app.post('/api/register', (req, res) => {
  const { name, email, phone, password } = req.body || {};
  if (!name || name.trim().length < 2) return bad(res, 'Please enter your name');
  if (!/^\S+@\S+\.\S+$/.test(email || '')) return bad(res, 'Please enter a valid email');
  if (!/^\d{10}$/.test(phone || '')) return bad(res, 'Phone number must be 10 digits');
  if (!password || password.length < 6) return bad(res, 'Password must be at least 6 characters');
  const db = loadDb();
  if (db.users.some(u => u.email === email.toLowerCase())) return bad(res, 'An account with this email already exists', 409);
  const user = { id: crypto.randomUUID(), name: name.trim(), email: email.toLowerCase(), phone, password: hashPassword(password), createdAt: new Date().toISOString() };
  db.users.push(user);
  const token = createSession(db, user.id);
  saveDb(db);
  res.status(201).json({ token, user: publicUser(user) });
});

app.post('/api/login', (req, res) => {
  const { email, password } = req.body || {};
  const db = loadDb();
  const user = db.users.find(u => u.email === (email || '').toLowerCase());
  if (!user || !verifyPassword(password || '', user.password)) return bad(res, 'Incorrect email or password', 401);
  const token = createSession(db, user.id);
  saveDb(db);
  res.json({ token, user: publicUser(user) });
});

app.post('/api/logout', auth, (req, res) => {
  req.db.sessions = req.db.sessions.filter(s => s.token !== req.token);
  saveDb(req.db);
  res.json({ ok: true });
});

app.get('/api/me', auth, (req, res) => res.json(publicUser(req.user)));

app.put('/api/me', auth, (req, res) => {
  const { name, phone } = req.body || {};
  if (!name || name.trim().length < 2) return bad(res, 'Please enter your name');
  if (!/^\d{10}$/.test(phone || '')) return bad(res, 'Phone number must be 10 digits');
  req.user.name = name.trim();
  req.user.phone = phone;
  saveDb(req.db);
  res.json(publicUser(req.user));
});

app.put('/api/me/password', auth, (req, res) => {
  const { currentPassword, newPassword } = req.body || {};
  if (!verifyPassword(currentPassword || '', req.user.password)) return bad(res, 'Current password is incorrect');
  if (!newPassword || newPassword.length < 6) return bad(res, 'New password must be at least 6 characters');
  req.user.password = hashPassword(newPassword);
  saveDb(req.db);
  res.json({ ok: true });
});

/* ------------------------------------------------------------------ */
/* Catalogue routes                                                    */
/* ------------------------------------------------------------------ */
app.get('/api/movies', (req, res) => {
  const q = (req.query.q || '').toLowerCase();
  const lang = req.query.language || '';
  res.json(MOVIES.filter(m =>
    (!q || (m.title + ' ' + m.genre + ' ' + m.cast).toLowerCase().includes(q)) &&
    (!lang || m.language === lang)));
});

app.get('/api/movies/:id', (req, res) => {
  const m = MOVIES.find(x => x.id === Number(req.params.id));
  if (!m) return bad(res, 'Movie not found', 404);
  res.json(m);
});

app.get('/api/dates', (req, res) => res.json(nextDates()));

app.get('/api/shows', (req, res) => {
  const { movieId, date } = req.query;
  if (!MOVIES.some(m => m.id === Number(movieId))) return bad(res, 'Movie not found', 404);
  if (!nextDates().includes(date)) return bad(res, 'Invalid date');
  res.json(THEATRES.map(t => ({
    theatre: t,
    times: TIMES.map(time => ({ time, past: showStart(date, time) < new Date() }))
  })));
});

app.get('/api/seats', (req, res) => {
  const v = validateShow(req.query);
  if (v.error) return bad(res, v.error);
  const db = loadDb();
  res.json({
    movie: v.movie, theatre: v.theatre, date: req.query.date, time: req.query.time,
    booked: bookedSeats(db, req.query.movieId, req.query.theatreId, req.query.date, req.query.time),
    rows: ROWS, cols: COLS, prices: ROW_PRICE, classes: ROW_CLASS, maxSeats: MAX_SEATS
  });
});

app.post('/api/quote', (req, res) => {
  const err = validateSeats((req.body || {}).seats);
  if (err) return bad(res, err);
  res.json(quote(req.body.seats));
});

/* ------------------------------------------------------------------ */
/* Booking routes                                                      */
/* ------------------------------------------------------------------ */
app.post('/api/bookings', auth, (req, res) => {
  const { movieId, theatreId, date, time, seats, payment } = req.body || {};
  const v = validateShow({ movieId, theatreId, date, time });
  if (v.error) return bad(res, v.error);
  const seatErr = validateSeats(seats);
  if (seatErr) return bad(res, seatErr);
  if (!payment || !PAYMENT_METHODS.includes(payment.method)) return bad(res, 'Invalid payment method');

  const taken = bookedSeats(req.db, movieId, theatreId, date, time);
  const clash = seats.filter(s => taken.includes(s));
  if (clash.length) return bad(res, `Seat(s) already booked: ${clash.join(', ')}`, 409);

  const q = quote(seats);
  const booking = {
    id: 'BK' + crypto.randomBytes(4).toString('hex').toUpperCase(),
    userId: req.user.id,
    movieId: v.movie.id, movieTitle: v.movie.title, language: v.movie.language,
    emoji: v.movie.emoji, colors: v.movie.colors,
    theatreId: v.theatre.id, theatreName: v.theatre.name, theatreArea: v.theatre.area,
    date, time, seats: [...seats].sort(),
    amount: q,
    // Demo payment: no card/bank details are ever sent to or stored on the server.
    payment: { method: payment.method, status: 'success', txnId: 'TXN' + crypto.randomBytes(5).toString('hex').toUpperCase(), paidAt: new Date().toISOString() },
    status: 'confirmed',
    createdAt: new Date().toISOString()
  };
  req.db.bookings.push(booking);
  saveDb(req.db);
  res.status(201).json(booking);
});

app.get('/api/bookings', auth, (req, res) => {
  const mine = req.db.bookings.filter(b => b.userId === req.user.id)
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  res.json(mine);
});

app.get('/api/bookings/:id', auth, (req, res) => {
  const b = req.db.bookings.find(x => x.id === req.params.id && x.userId === req.user.id);
  if (!b) return bad(res, 'Booking not found', 404);
  res.json(b);
});

app.post('/api/bookings/:id/cancel', auth, (req, res) => {
  const b = req.db.bookings.find(x => x.id === req.params.id && x.userId === req.user.id);
  if (!b) return bad(res, 'Booking not found', 404);
  if (b.status !== 'confirmed') return bad(res, 'Booking is already cancelled');
  if (showStart(b.date, b.time) < new Date()) return bad(res, 'Past shows cannot be cancelled');
  b.status = 'cancelled';
  b.cancelledAt = new Date().toISOString();
  b.refund = b.amount.subtotal; // convenience fee + GST are non-refundable
  saveDb(req.db);
  res.json(b);
});

/* ------------------------------------------------------------------ */
app.use('/api', (req, res) => bad(res, 'Not found', 404));

app.listen(PORT, () => console.log(`CineBook running at http://localhost:${PORT}`));
