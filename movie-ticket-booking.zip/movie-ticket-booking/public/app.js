/* CineBook - shared frontend logic. Each HTML page sets <body data-page="..."> */

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const rupee = n => '₹' + Number(n).toLocaleString('en-IN');
const qs = new URLSearchParams(location.search);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const debounce = (fn, ms) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };

/* ---------- auth state ---------- */
const getToken = () => localStorage.getItem('cb_token');
const getUser = () => { try { return JSON.parse(localStorage.getItem('cb_user')); } catch { return null; } };
function setAuth(token, user) { localStorage.setItem('cb_token', token); localStorage.setItem('cb_user', JSON.stringify(user)); }
function clearAuth() { localStorage.removeItem('cb_token'); localStorage.removeItem('cb_user'); sessionStorage.removeItem('draft'); }

/* ---------- API ---------- */
async function api(path, opts = {}) {
  const headers = { 'Content-Type': 'application/json' };
  if (getToken()) headers.Authorization = 'Bearer ' + getToken();
  const res = await fetch('/api' + path, {
    method: opts.method || 'GET', headers,
    body: opts.body ? JSON.stringify(opts.body) : undefined
  });
  const data = await res.json().catch(() => ({}));
  if (res.status === 401 && getToken()) { clearAuth(); }
  if (!res.ok) { const e = new Error(data.error || 'Something went wrong'); e.status = res.status; throw e; }
  return data;
}

/* ---------- UI helpers ---------- */
function toast(msg, type = 'ok') {
  let box = $('#toast');
  if (!box) { box = document.createElement('div'); box.id = 'toast'; document.body.appendChild(box); }
  const t = document.createElement('div');
  t.className = 'toast ' + type; t.textContent = msg; box.appendChild(t);
  setTimeout(() => t.remove(), 3500);
}
function fmtDate(s) {
  const [y, m, d] = s.split('-').map(Number);
  return new Date(y, m - 1, d).toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short' });
}
function poster(m, cls = '') {
  return `<div class="poster ${cls}" style="background:linear-gradient(145deg,${m.colors[0]},${m.colors[1]})">
    <div class="emoji">${m.emoji}</div><div class="ptitle">${esc(m.title)}</div></div>`;
}
function requireLogin() {
  if (getToken()) return true;
  location.href = 'login.html?next=' + encodeURIComponent(location.pathname.split('/').pop() + location.search);
  return false;
}
function getDraft() { try { return JSON.parse(sessionStorage.getItem('draft')); } catch { return null; } }
function requireDraft() {
  const d = getDraft();
  if (!d || !d.seats || !d.seats.length) { location.href = 'index.html'; return null; }
  return d;
}
const METHOD_LABEL = { debit: 'Debit Card', netbanking: 'Net Banking', phonepe: 'PhonePe (UPI)', gpay: 'Google Pay (UPI)', paytm: 'Paytm (UPI)' };

function renderNav() {
  const el = $('#nav'); if (!el) return;
  const u = getUser(), here = location.pathname.split('/').pop() || 'index.html';
  const a = (href, label, cls = '') => `<a href="${href}" class="${cls} ${here === href ? 'active' : ''}">${label}</a>`;
  el.innerHTML = `<div class="wrap nav-inner"><a class="brand" href="index.html">🎬 Cine<span>Book</span></a><nav>
    ${a('index.html', 'Movies')}
    ${u ? a('my-bookings.html', 'My Bookings') + a('profile.html', '👤 ' + esc(u.name.split(' ')[0])) + '<button id="logout">Logout</button>'
        : a('login.html', 'Login') + a('register.html', 'Sign up', 'cta')}
  </nav></div>`;
  const lo = $('#logout');
  if (lo) lo.onclick = async () => { try { await api('/logout', { method: 'POST' }); } catch {} clearAuth(); location.href = 'index.html'; };
}

/* ---------- payment helpers ---------- */
async function showAmount(sel = '#amount') {
  const d = requireDraft(); if (!d) return null;
  const q = await api('/quote', { method: 'POST', body: { seats: d.seats } });
  const el = $(sel); if (el) el.textContent = rupee(q.total);
  const sum = $('#pay-summary');
  if (sum) sum.innerHTML = `<b>${esc(d.movieTitle)}</b><br><span class="muted small">${esc(d.theatreName)} · ${fmtDate(d.date)} · ${esc(d.time)}<br>Seats: ${d.seats.join(', ')}</span>`;
  return q;
}
async function payAndConfirm(method, btn) {
  const d = getDraft(); if (!d) return;
  if (btn) btn.disabled = true;
  try {
    const b = await api('/bookings', {
      method: 'POST',
      body: { movieId: d.movieId, theatreId: d.theatreId, date: d.date, time: d.time, seats: d.seats, payment: { method } }
    });
    sessionStorage.removeItem('draft');
    location.href = 'booking-confirmed.html?id=' + b.id;
  } catch (e) {
    toast(e.message, 'error');
    if (btn) btn.disabled = false;
    if (e.status === 409) setTimeout(() => {
      location.href = `seat-selection.html?movieId=${d.movieId}&theatreId=${d.theatreId}&date=${d.date}&time=${encodeURIComponent(d.time)}`;
    }, 1800);
    else if (e.status === 401) setTimeout(requireLogin, 1200);
  }
}
function payGuard() { return requireLogin() && showAmount(); }

/* UPI flow shared by gpay-redirect.html and open-paytm.html (demo simulation) */
function upiFlow(method) {
  if (!payGuard()) return;
  const step1 = $('#step1'), step2 = $('#step2'), idInput = $('#upi-id'), err = $('#upi-err');
  $('#send').onclick = () => {
    if (!/^[\w.\-]{2,}@[a-zA-Z]{2,}$/.test(idInput.value.trim())) { err.textContent = 'Enter a valid UPI ID, e.g. name@bank'; return; }
    err.textContent = ''; step1.hidden = true; step2.hidden = false;
    $('#upi-shown').textContent = idInput.value.trim();
  };
  $('#approve').onclick = e => payAndConfirm(method, e.target);
  $('#decline').onclick = () => { toast('Payment request declined', 'error'); setTimeout(() => location.href = 'pay-now.html', 900); };
}

const pages = {
  /* ================= HOME ================= */
  home() {
    const grid = $('#movies'), search = $('#search'), lang = $('#lang');
    const card = m => `<a class="movie-card" href="movie-details.html?id=${m.id}">${poster(m)}
      <div class="info"><h3>${esc(m.title)}</h3>
      <div class="small muted">${esc(m.genre)}</div>
      <div style="margin-top:6px"><span class="rating">★ ${m.rating}</span> <span class="tag">${m.language}</span><span class="tag">${m.certificate}</span></div></div></a>`;
    async function load() {
      const p = new URLSearchParams();
      if (search.value.trim()) p.set('q', search.value.trim());
      if (lang.value) p.set('language', lang.value);
      try {
        const list = await api('/movies?' + p);
        grid.innerHTML = list.length ? list.map(card).join('') : '<p class="muted">No movies match your search.</p>';
      } catch (e) { grid.innerHTML = '<p class="muted">Could not load movies.</p>'; }
    }
    search.addEventListener('input', debounce(load, 250));
    lang.addEventListener('change', load);
    load();
  },

  /* ================= AUTH ================= */
  login() {
    $('#login-form').onsubmit = async e => {
      e.preventDefault(); $('#err').textContent = '';
      try {
        const r = await api('/login', { method: 'POST', body: { email: $('#email').value, password: $('#password').value } });
        setAuth(r.token, r.user);
        location.href = qs.get('next') || 'index.html';
      } catch (err) { $('#err').textContent = err.message; }
    };
  },
  register() {
    $('#register-form').onsubmit = async e => {
      e.preventDefault(); $('#err').textContent = '';
      if ($('#password').value !== $('#confirm').value) { $('#err').textContent = 'Passwords do not match'; return; }
      try {
        const r = await api('/register', { method: 'POST', body: { name: $('#name').value, email: $('#email').value, phone: $('#phone').value, password: $('#password').value } });
        setAuth(r.token, r.user);
        location.href = qs.get('next') || 'index.html';
      } catch (err) { $('#err').textContent = err.message; }
    };
  },

  /* ================= MOVIE DETAILS ================= */
  async details() {
    const id = qs.get('id');
    let m;
    try { m = await api('/movies/' + id); } catch { $('#content').innerHTML = '<p>Movie not found. <a href="index.html" style="color:var(--brand)">Back to movies</a></p>'; return; }
    document.title = m.title + ' - CineBook';
    $('#info').innerHTML = `${poster(m)}<div>
      <h1>${esc(m.title)}</h1>
      <p style="margin:8px 0"><span class="rating">★ ${m.rating}/10</span> <span class="tag">${m.language}</span><span class="tag">${m.certificate}</span><span class="tag">${m.duration}</span></p>
      <p class="muted" style="margin-bottom:14px">${esc(m.genre)}</p>
      <p style="margin-bottom:14px">${esc(m.description)}</p>
      <p><b>Director:</b> <span class="muted">${esc(m.director)}</span></p>
      <p><b>Cast:</b> <span class="muted">${esc(m.cast)}</span></p></div>`;
    const dates = await api('/dates');
    let sel = dates[0];
    const renderDates = () => {
      $('#dates').innerHTML = dates.map(d => {
        const [y, mo, da] = d.split('-').map(Number), dt = new Date(y, mo - 1, da);
        return `<button class="date-btn ${d === sel ? 'active' : ''}" data-d="${d}"><small>${dt.toLocaleDateString('en-IN', { weekday: 'short' })}</small><b>${da}</b><small>${dt.toLocaleDateString('en-IN', { month: 'short' })}</small></button>`;
      }).join('');
      $$('.date-btn').forEach(b => b.onclick = () => { sel = b.dataset.d; renderDates(); loadShows(); });
    };
    async function loadShows() {
      const shows = await api(`/shows?movieId=${m.id}&date=${sel}`);
      $('#shows').innerHTML = shows.map(s => `<div class="show-row">
        <div><h3>${esc(s.theatre.name)}</h3><div class="muted small">${esc(s.theatre.area)}</div></div>
        <div class="times">${s.times.map(t => `<button class="time-btn" ${t.past ? 'disabled' : ''} data-t="${esc(t.time)}" data-th="${s.theatre.id}">${t.time}</button>`).join('')}</div></div>`).join('');
      $$('.time-btn').forEach(b => b.onclick = () => {
        location.href = `seat-selection.html?movieId=${m.id}&theatreId=${b.dataset.th}&date=${sel}&time=${encodeURIComponent(b.dataset.t)}`;
      });
    }
    renderDates(); loadShows();
  },

  /* ================= SEAT SELECTION ================= */
  async seats() {
    const params = { movieId: qs.get('movieId'), theatreId: qs.get('theatreId'), date: qs.get('date'), time: qs.get('time') };
    let data;
    try { data = await api('/seats?' + new URLSearchParams(params)); }
    catch (e) { $('#content').innerHTML = `<p>${esc(e.message)}. <a href="index.html" style="color:var(--brand)">Back to movies</a></p>`; return; }
    $('#show-info').innerHTML = `<h1>${esc(data.movie.title)}</h1><p class="muted">${esc(data.theatre.name)}, ${esc(data.theatre.area)} · ${fmtDate(data.date)} · ${esc(data.time)}</p>`;
    const selected = new Set(), booked = new Set(data.booked);
    let html = '', lastClass = '';
    for (const r of data.rows) {
      if (data.classes[r] !== lastClass) {
        lastClass = data.classes[r];
        html += `<div class="class-label">${lastClass.toUpperCase()} · ${rupee(data.prices[r])}</div>`;
      }
      html += `<div class="seat-row"><span class="row-name">${r}</span>`;
      for (let c = 1; c <= data.cols; c++) {
        const id = r + c;
        html += `<button class="seat ${booked.has(id) ? 'sold' : ''}" data-s="${id}" ${booked.has(id) ? 'disabled' : ''}>${c}</button>`;
        if (c === data.cols / 2) html += '<span class="aisle"></span>';
      }
      html += '</div>';
    }
    $('#seat-map').innerHTML = html;
    const update = () => {
      const list = [...selected].sort();
      const total = list.reduce((a, s) => a + data.prices[s[0]], 0);
      $('#sel-seats').textContent = list.length ? list.join(', ') : 'None selected';
      $('#sel-total').textContent = rupee(total);
      $('#continue').disabled = !list.length;
    };
    $$('.seat:not(.sold)').forEach(b => b.onclick = () => {
      const s = b.dataset.s;
      if (selected.has(s)) selected.delete(s);
      else if (selected.size >= data.maxSeats) { toast(`You can select up to ${data.maxSeats} seats`, 'error'); return; }
      else selected.add(s);
      b.classList.toggle('selected'); update();
    });
    $('#continue').onclick = () => {
      sessionStorage.setItem('draft', JSON.stringify({
        ...params, movieTitle: data.movie.title, theatreName: data.theatre.name, seats: [...selected].sort()
      }));
      location.href = 'ticket-summary.html';
    };
    update();
  },

  /* ================= TICKET SUMMARY ================= */
  async summary() {
    if (!requireLogin()) return;
    const d = requireDraft(); if (!d) return;
    const q = await api('/quote', { method: 'POST', body: { seats: d.seats } });
    $('#details').innerHTML = `<h2>${esc(d.movieTitle)}</h2>
      <div class="kv"><span class="muted">Theatre</span><b>${esc(d.theatreName)}</b></div>
      <div class="kv"><span class="muted">Date</span><b>${fmtDate(d.date)}</b></div>
      <div class="kv"><span class="muted">Show time</span><b>${esc(d.time)}</b></div>
      <div class="kv"><span class="muted">Seats</span><b>${d.seats.join(', ')}</b></div>`;
    $('#price').innerHTML = `<h2>Price details</h2>
      ${q.items.map(i => `<div class="kv"><span>${i.seat} <span class="muted small">(${i.class})</span></span><span>${rupee(i.price)}</span></div>`).join('')}
      <div class="kv"><span class="muted">Convenience fee</span><span>${rupee(q.fee)}</span></div>
      <div class="kv"><span class="muted">GST on fee (18%)</span><span>${rupee(q.gst)}</span></div>
      <div class="kv total"><span>Total payable</span><span>${rupee(q.total)}</span></div>`;
    $('#edit').href = `seat-selection.html?movieId=${d.movieId}&theatreId=${d.theatreId}&date=${d.date}&time=${encodeURIComponent(d.time)}`;
  },

  /* ================= PAY NOW (choose method) ================= */
  async paynow() {
    if (!requireLogin()) return;
    await showAmount();
    const pages = { debit: 'debit.html', netbanking: 'net-banking.html', phonepe: 'phone-pay.html', gpay: 'gpay-redirect.html', paytm: 'open-paytm.html' };
    $$('.pay-option').forEach(o => o.onclick = () => { $$('.pay-option').forEach(x => x.classList.remove('sel')); o.classList.add('sel'); o.querySelector('input').checked = true; });
    $('#pay-continue').onclick = () => {
      const m = (document.querySelector('input[name=method]:checked') || {}).value;
      if (!m) { toast('Choose a payment method', 'error'); return; }
      location.href = pages[m];
    };
  },

  /* ================= DEBIT CARD ================= */
  debit() {
    if (!payGuard()) return;
    const num = $('#card'), exp = $('#exp'), cvv = $('#cvv'), nm = $('#holder'), err = $('#err');
    num.oninput = () => { num.value = num.value.replace(/\D/g, '').slice(0, 16).replace(/(.{4})/g, '$1 ').trim(); };
    exp.oninput = () => { let v = exp.value.replace(/\D/g, '').slice(0, 4); if (v.length > 2) v = v.slice(0, 2) + '/' + v.slice(2); exp.value = v; };
    cvv.oninput = () => { cvv.value = cvv.value.replace(/\D/g, '').slice(0, 3); };
    const luhn = s => { let sum = 0, alt = false; for (let i = s.length - 1; i >= 0; i--) { let n = +s[i]; if (alt) { n *= 2; if (n > 9) n -= 9; } sum += n; alt = !alt; } return sum % 10 === 0; };
    $('#card-form').onsubmit = e => {
      e.preventDefault(); err.textContent = '';
      const digits = num.value.replace(/\s/g, '');
      if (nm.value.trim().length < 2) return err.textContent = 'Enter the name on the card';
      if (digits.length !== 16 || !luhn(digits)) return err.textContent = 'Enter a valid 16-digit card number';
      const m = exp.value.match(/^(\d{2})\/(\d{2})$/);
      if (!m || +m[1] < 1 || +m[1] > 12) return err.textContent = 'Enter expiry as MM/YY';
      const now = new Date();
      if (new Date(2000 + +m[2], +m[1], 0, 23, 59) < now) return err.textContent = 'This card has expired';
      if (cvv.value.length !== 3) return err.textContent = 'Enter the 3-digit CVV';
      // Card details stay in the browser; only the method name is sent to the server.
      payAndConfirm('debit', $('#pay-btn'));
    };
  },

  /* ================= NET BANKING ================= */
  netbanking() {
    if (!payGuard()) return;
    let bank = '';
    $$('.bank').forEach(b => b.onclick = () => { $$('.bank').forEach(x => x.classList.remove('sel')); b.classList.add('sel'); bank = b.dataset.b; $('#bank-name').textContent = bank; });
    $('#pay-btn').onclick = e => {
      if (!bank) { toast('Select your bank', 'error'); return; }
      payAndConfirm('netbanking', e.target);
    };
  },

  /* ================= UPI PAGES ================= */
  gpay() { upiFlow('gpay'); },
  paytm() { upiFlow('paytm'); },
  phonepay() {
    if (!payGuard()) return;
    $('#upi-form').onsubmit = e => {
      e.preventDefault();
      const v = $('#upi-id').value.trim();
      if (!/^[\w.\-]{2,}@[a-zA-Z]{2,}$/.test(v)) { $('#upi-err').textContent = 'Enter a valid UPI ID, e.g. name@bank'; return; }
      sessionStorage.setItem('upiId', v);
      location.href = 'open-phone-pay.html';
    };
  },
  openphonepay() {
    if (!payGuard()) return;
    const id = sessionStorage.getItem('upiId');
    if (!id) { location.href = 'phone-pay.html'; return; }
    $('#upi-shown').textContent = id;
    let left = 60; const t = setInterval(() => { left--; $('#timer').textContent = left; if (left <= 0) { clearInterval(t); toast('Request timed out', 'error'); setTimeout(() => location.href = 'pay-now.html', 1000); } }, 1000);
    $('#approve').onclick = e => { clearInterval(t); payAndConfirm('phonepe', e.target); };
    $('#decline').onclick = () => { clearInterval(t); toast('Payment request declined', 'error'); setTimeout(() => location.href = 'pay-now.html', 900); };
  },

  /* ================= BOOKING CONFIRMED ================= */
  async confirmed() {
    if (!requireLogin()) return;
    try {
      const b = await api('/bookings/' + qs.get('id'));
      $('#ticket').innerHTML = ticketHtml(b);
      $('#status-msg').innerHTML = b.status === 'confirmed'
        ? '<h1>🎉 Booking confirmed!</h1><p class="muted">Show this ticket at the theatre entrance.</p>'
        : '<h1>Booking cancelled</h1><p class="muted">This ticket is no longer valid.</p>';
    } catch (e) { $('#ticket').innerHTML = `<p>${esc(e.message)}</p>`; }
    $('#print').onclick = () => window.print();
  },

  /* ================= MY BOOKINGS ================= */
  async bookings() {
    if (!requireLogin()) return;
    const box = $('#list');
    async function load() {
      try {
        const list = await api('/bookings');
        box.innerHTML = list.length ? list.map(b => `<div class="card booking-item">
          <div class="mini" style="background:linear-gradient(145deg,${b.colors[0]},${b.colors[1]})">${b.emoji}</div>
          <div class="grow"><h3>${esc(b.movieTitle)} <span class="badge ${b.status}">${b.status}</span></h3>
            <div class="muted small">${esc(b.theatreName)} · ${fmtDate(b.date)} · ${esc(b.time)}</div>
            <div class="small">Seats: ${b.seats.join(', ')} · Paid ${rupee(b.amount.total)}</div>
            <div class="muted small">Booking ID ${b.id}${b.refund != null ? ' · Refund ' + rupee(b.refund) : ''}</div></div>
          <div><a class="btn ghost" href="booking-confirmed.html?id=${b.id}">View ticket</a>
          ${b.status === 'confirmed' ? `<button class="btn danger cancel" data-id="${b.id}">Cancel</button>` : ''}</div></div>`).join('')
          : '<div class="card center"><p class="muted">No bookings yet.</p><br><a class="btn" href="index.html">Book a movie</a></div>';
        $$('.cancel').forEach(btn => btn.onclick = async () => {
          if (!confirm('Cancel this booking? Convenience fee and GST are non-refundable.')) return;
          try { const r = await api(`/bookings/${btn.dataset.id}/cancel`, { method: 'POST' }); toast('Cancelled. Refund: ' + rupee(r.refund)); load(); }
          catch (e) { toast(e.message, 'error'); }
        });
      } catch (e) { box.innerHTML = `<p>${esc(e.message)}</p>`; }
    }
    load();
  },

  /* ================= PROFILE ================= */
  async profile() {
    if (!requireLogin()) return;
    let u;
    try { u = await api('/me'); } catch { requireLogin(); return; }
    $('#name').value = u.name; $('#phone').value = u.phone; $('#email').value = u.email;
    $('#profile-form').onsubmit = async e => {
      e.preventDefault();
      try { const r = await api('/me', { method: 'PUT', body: { name: $('#name').value, phone: $('#phone').value } }); setAuth(getToken(), r); renderNav(); toast('Profile updated'); }
      catch (err) { toast(err.message, 'error'); }
    };
    $('#pw-form').onsubmit = async e => {
      e.preventDefault();
      try { await api('/me/password', { method: 'PUT', body: { currentPassword: $('#cur').value, newPassword: $('#new').value } }); toast('Password changed'); e.target.reset(); }
      catch (err) { toast(err.message, 'error'); }
    };
  }
};

function ticketHtml(b) {
  return `<div class="ticket">
    <div class="ticket-top" style="background:linear-gradient(145deg,${b.colors[0]},${b.colors[1]})">
      <div class="emoji">${b.emoji}</div>
      <div><h2 style="margin:0">${esc(b.movieTitle)}</h2><div>${esc(b.language)} · <span class="badge ${b.status}">${b.status}</span></div></div></div>
    <div class="ticket-body">
      <div><small>Theatre</small>${esc(b.theatreName)}, ${esc(b.theatreArea)}</div>
      <div><small>Date</small>${fmtDate(b.date)}</div>
      <div><small>Show time</small>${esc(b.time)}</div>
      <div><small>Seats</small><b>${b.seats.join(', ')}</b></div>
      <div><small>Amount paid</small>${rupee(b.amount.total)}</div>
      <div><small>Payment</small>${METHOD_LABEL[b.payment.method]} · ${b.payment.txnId}</div>
    </div>
    <div class="barcode">${b.id}</div></div>`;
}

document.addEventListener('DOMContentLoaded', () => {
  renderNav();
  const fn = pages[document.body.dataset.page];
  if (fn) fn();
});
